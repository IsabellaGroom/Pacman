#include "Pacman.h"

//Entry Point for Application
int main(int argc, char* argv[]) {
	Pacman* game = new Pacman(argc, argv);
}