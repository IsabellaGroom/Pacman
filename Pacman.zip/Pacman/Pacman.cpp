#include "Pacman.h"
#include <time.h>
#include <sstream>
#include <iostream>

//declears global variables to be used across functions
bool fwd = false;
bool _right = false;
bool _left = false;
bool dwn = false;

int score = 0;
int rndScore = 0;
bool hasWon = false;
bool drawCherry = false;

Pacman::Pacman(int argc, char* argv[]) : Game(argc, argv), _cPacmanSpeed(0.1f), _cPacmanFrameTime(250)
{
	//initialises Soundeffects
	_waka = new SoundEffect();
	_death = new SoundEffect();
	_win = new SoundEffect();

	//sets up instances of structs in header file and its variables
	_menu = new Menu();
	_pacman = new Player();
	_cherry = new Enemy();
	
	//initialises bools for menu struct
	_menu->paused = false;
	_menu->pKeyDown = false;
	_menu->start = true;
	_menu->sKeyDown = false;

	//initalises variables for pacman
	_pacman->isDead = false;
	_pacman->direction = 0;
	_pacman->currentFrameTime = 0;
	_pacman->frame = 0;
	_pacman->speedMultipier = 1.0f;

	//initialises variables for cherry
	_cherry->frameCount = rand() % 1;
	_cherry->currentFrameTime = 0;
	_cherry->frameTime = rand() % 500 + 50;

	//randomises numbers based on time
	srand(time(NULL));

	//random score for cherry to be drawn at
	rndScore = rand() % 50;
	
	//sets up munchies
	for (int i = 0; i < MUNCHIECOUNT; i++)
	{
		_munchies[i] = new Enemy();
		_munchies[i]->frameCount = rand() % 1;
		_munchies[i]->currentFrameTime = 0;
		_munchies[i]->frameTime = rand() % 500 + 50;
	}

	//sets up ghosts
	for (int i = 0; i < GHOSTCOUNT; i++)
	{
		_ghosts[i] = new MovingEnemy();
		
		if (_ghosts[i] == _ghosts[0])
		{
			//AI ghost needed to be slower
			_ghosts[0]->speed = 0.13f;
		}
		else
		{
			_ghosts[i]->speed = 0.2f; 
		}
		_ghosts[i]->direction = rand() % 4;
		_ghosts[i]->currentFrameTime = 0;
		_ghosts[i]->frame = 0;
	}

	//Initialise important Game aspects
	Audio::Initialise();
	Graphics::Initialise(argc, argv, this, 1024, 768, false, 25, 25, "Pacman", 60);
	Input::Initialise();

	// Start the Game Loop - This calls Update and Draw in game loop
	Graphics::StartGameLoop();
}

Pacman::~Pacman()
{
	//deletes objects
	delete _waka;
	delete _death;
	delete _win;

	delete _pacman->texture;
	delete _pacman->sourceRect;

	delete _cherry->texture;
	delete _cherry->sourceRect;

	delete _munchies[0]->texture;

	for (int i = 0; i < MUNCHIECOUNT; i++)
	{
		delete _munchies[i]->position;
		delete _munchies[i]->sourceRect;
		delete _munchies[i];
	}

	delete[] _munchies;

	
	for (int i = 0; i < GHOSTCOUNT; i++)
	{
		delete _ghosts[i]->texture;
		delete _ghosts[i]->position;
		delete _ghosts[i]->sourceRect;
		delete _ghosts[i];
	}

	delete[] _ghosts;
}

void Pacman::LoadContent()
{

	// Load Pacman
	_pacman->texture = new Texture2D();
	_pacman->texture->Load("Textures/Pacman.tga", false);

	_pacman->position = new Vector2(350.0f, 350.0f);
	_pacman->sourceRect = new Rect(0.0f, 0.0f, 32, 32);
	
	//Load cherry
	Texture2D* cherryTexture = new Texture2D();
	cherryTexture->Load("Textures/Cherries.png", false);

	_cherry->texture = cherryTexture;
	_cherry->position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
	_cherry->sourceRect = new Rect(0.0f, 0.0f, 32, 32);

	// Load Munchies
	Texture2D* munchieTexture = new Texture2D();
	munchieTexture->Load("Textures/Munchies.png", false);

	for (int i = 0; i < MUNCHIECOUNT; i++)
	{
		_munchies[i]->texture = munchieTexture;
		_munchies[i]->position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
		_munchies[i]->sourceRect = new Rect(0.0f, 0.0f, 12, 12);
	}

	//Load Ghosts
	_ghosts[0]->texture = new Texture2D();
	_ghosts[0]->texture->Load("Textures/BlueGhost.png", false);

	_ghosts[1]->texture = new Texture2D();
	_ghosts[1]->texture->Load("Textures/OrangeGhost.png", false);

	_ghosts[2]->texture = new Texture2D();
	_ghosts[2]->texture->Load("Textures/RedGhost.png", false);

	_ghosts[3]->texture = new Texture2D();
	_ghosts[3]->texture->Load("Textures/PinkGhost.png", false);

	//random spawn position
	for (int i = 0; i < GHOSTCOUNT; i++)
	{
		_ghosts[i]->position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
		_ghosts[i]->sourceRect = new Rect(0.0f, 0.0f, 24, 24);
	}
	
	
	// Set string position
	_stringPosition = new Vector2(10.0f, 25.0f);

	//Set Menu Paramenters
	_menu->background = new Texture2D();
	_menu->background->Load("Textures/Transparency.png", false);
	_menu->rectangle = new Rect(0.0f, 0.0f, Graphics::GetViewportWidth(), Graphics::GetViewportHeight());
	_menu->stringPosition = new Vector2(Graphics::GetViewportWidth() / 2.0f, Graphics::GetViewportHeight() / 2.0f);

	//Load Sounds
	_waka->Load("Sounds/waka_waka.wav");
	_death->Load("Sounds/death.wav");
	_win->Load("Sounds/win.wav");
}

void Pacman::Update(int elapsedTime)
{
	/* //For debugging audio
	if (!Audio::IsInitialised())
	{
		std::cout << "Audio is not initialised" << std::endl;
	}
	if (!_waka->IsLoaded())
	{
		std::cout << "waka has not loaded" << std::endl;
	}
	*/

	// Gets the current state of the keyboard and mouse
	Input::KeyboardState* keyboardState = Input::Keyboard::GetState();
	Input::MouseState* mouseState = Input::Mouse::GetState();

	if (_menu->start)
	{
		//Checks if game has started
		CheckStart(keyboardState, Input::Keys::SPACE);
	}
	if (!_menu->start)
	{
		//Checks if game is being paused
		CheckPaused(keyboardState, Input::Keys::P);
		if (!_menu->paused)
		{
			//checks if pacman is dead
			if (!_pacman->isDead)
			{
				//checks if the player has won the game
				if (!hasWon)
				{
					//Functions for pacman, checks input, collision with the level boundaries and animates + moves pacman
					Input(elapsedTime, keyboardState, mouseState);
					CheckViewportCollision();
					UpdatePacman(elapsedTime);

					//Updates Muncheis
					for (int i = 0; i < MUNCHIECOUNT; i++)
					{
						UpdateMunchie(_munchies[i], elapsedTime);

						//If pacman collides with munchies, play a sound and move the munchie off screen, increment score.
						if (CheckCollision(_pacman->position->X, _pacman->position->Y, _pacman->sourceRect->Width, _pacman->sourceRect->Height, _munchies[i]->position->X, _munchies[i]->position->Y, _munchies[i]->sourceRect->Width, _munchies[i]->sourceRect->Height))
						{
							Audio::Play(_waka);
							_munchies[i]->position = new Vector2(1000, 1000);
							score++;
						}
					}

					//Updates Ghosts
					for (int i = 0; i < GHOSTCOUNT; i++)
					{
						if (_ghosts[i] == _ghosts[0])
						{
							//Separate update function for the AI ghost
							GhostChaseDirection(_ghosts[0],elapsedTime, _ghosts[0]->position->X, _ghosts[0]->position->Y, _ghosts[0]->sourceRect->Width, _ghosts[0]->sourceRect->Height, _pacman->position->X, _pacman->position->Y, _pacman->sourceRect->Width, _pacman->sourceRect->Height);
						}
						else
						{
							UpdateGhosts(_ghosts[i], elapsedTime);
						}
						//If the ghosts collide with pacman, lose the game and play the death sound
						if (CheckCollision(_pacman->position->X, _pacman->position->Y, _pacman->sourceRect->Width, _pacman->sourceRect->Height, _ghosts[i]->position->X, _ghosts[i]->position->Y, _ghosts[i]->sourceRect->Width, _ghosts[i]->sourceRect->Height))
						{
							_pacman->isDead = true;
							Audio::Play(_death);
							break;
						}
					}
					//if the current score is equal to the random score, draw the cherry.
					if (score == rndScore)
					{
						drawCherry = true;
					}
					//animates the cherry
					UpdateMunchie(_cherry, elapsedTime);

					//If pacman collides with the cherry, increase the score by 250
					if (CheckCollision(_pacman->position->X, _pacman->position->Y, _pacman->sourceRect->Width, _pacman->sourceRect->Height, _cherry->position->X, _cherry->position->Y, _cherry->sourceRect->Width, _cherry->sourceRect->Height))
					{
						_cherry->position = new Vector2(1000, 1000);
						score += 250;
					}
					//if the score is 300 then the player has won the game
					if (score == 300)
					{
						hasWon = true;
						Audio::Play(_win);
					}
				}
				
			}
		}
	}
}

void Pacman::Input(int elapsedTime, Input::KeyboardState* state, Input::MouseState* mouseState)
{
	//calculates pacmans speed
	float pacmanSpeed = _cPacmanSpeed * elapsedTime * _pacman->speedMultipier;

	//Sprint
	if (state->IsKeyDown(Input::Keys::LEFTSHIFT))
	{
		_pacman->speedMultipier = 2.0f;
	}
	else
	{
		_pacman->speedMultipier = 1.0f;
	}

	//Movement
	if (fwd == true)
	{
		_pacman->position->Y -= pacmanSpeed;
		_pacman->direction = 3;
	}
	else if (dwn)
	{
		_pacman->position->Y += pacmanSpeed;
		_pacman->direction = 1;
	}
	else if (_right)
	{
		_pacman->position->X += pacmanSpeed;
		_pacman->direction = 0;
	}
	else if (_left)
	{
		_pacman->position->X -= pacmanSpeed;
		_pacman->direction = 2;
	}

	//Direction
	//If WASD is pressed, pacman will go up, down, left, right
	if (state->IsKeyDown(Input::Keys::D))
	{
		_right = true;
		fwd = false;
		_left = false;
		dwn = false;

	}
	else if (state->IsKeyDown(Input::Keys::A))
	{
		_left = true;
		_right = false;
		dwn = false;
		fwd = false;

	}
	else if (state->IsKeyDown(Input::Keys::W))
	{
		fwd = true;
		dwn = false;
		_right = false;
		_left = false;

	}
	else if (state->IsKeyDown(Input::Keys::S))
	{
		dwn = true;
		fwd = false;
		_right = false;
		_left = false;

	}

	/*
	//Mouse controls
	if (mouseState->LeftButton == Input::ButtonState::PRESSED)
	{
		_cherry->position->X = mouseState->X;
		_cherry->position->Y = mouseState->Y;
	}
  */

	//Random cherry position
	if (state->IsKeyDown(Input::Keys::R))
	{
		_cherry->position = new Vector2((rand() % Graphics::GetViewportWidth()), (rand() % Graphics::GetViewportHeight()));
	}

}

void Pacman::CheckPaused(Input::KeyboardState*state, Input::Keys pauseKey)
{
	//if the P key is pressed pause/unpause
	if (state->IsKeyDown(pauseKey) && !_menu->pKeyDown)
	{
		_menu->pKeyDown = true;
		_menu->paused = !_menu->paused;
	}
	if (state->IsKeyUp(pauseKey))
	{
		_menu->pKeyDown = false;
	}
}

void Pacman::CheckStart(Input::KeyboardState* state, Input::Keys startKey)
{
	//if space key is hit, exit start screen
	if (state->IsKeyDown(startKey) && !_menu->sKeyDown)
	{
		_menu->start = !_menu->start;
	}
	if (state->IsKeyUp(startKey))
	{
		_menu->sKeyDown = false;
	}
}

void Pacman::CheckViewportCollision()
{
	//When pacman hits the edge of the screen, he will appear on the opposite side of the screen.
    //So when pacman hits the top of the screen, he will appear at the bottom.
	if (_pacman->position->X + _pacman->sourceRect->Width > Graphics::GetViewportWidth())
	{
		_pacman->position->X = 0;
	}
	else if (_pacman->position->Y + _pacman->sourceRect->Width > Graphics::GetViewportHeight())
	{
		_pacman->position->Y = 0;
	}
	else if (_pacman->position->Y - _pacman->sourceRect->Width < -32)
	{
		_pacman->position->Y = 730;
	}
	else if (_pacman->position->X - _pacman->sourceRect->Width < -32)
	{
		_pacman->position->X = 990;
	}
}

bool Pacman::CheckCollision(int x1, int y1, int width1, int height1, int x2, int y2, int width2, int height2)
{
	//calculates boundaries for the bounding box
	int left1 = x1;
	int left2 = x2;
	int right1 = x1 + width1;
	int right2 = x2 + width2;
	int top1 = y1;
	int top2 = y2;
	int bottom1 = y1 + height1;
	int bottom2 = y2 + height2;

	//if the boxes overlap return true
	if (bottom1 < top2)
	{
		return false;
	}
	if (top1 > bottom2)
	{
		return false;
	}
	if (right1 < left2)
	{
		return false;
	}
	if (left1 > right2)
	{
		return false;
	}
	
	return true;
}

void Pacman::UpdatePacman(int elapsedTime)
{
	//animates pacman
	_pacman->currentFrameTime += elapsedTime;

	if (_pacman->currentFrameTime > _cPacmanFrameTime)
	{
		_pacman->frame++;

		if (_pacman->frame >= 2)
		{
			_pacman->frame = 0;
		}

		_pacman->currentFrameTime = 0;
	}

	_pacman->sourceRect->Y = _pacman->sourceRect->Height * _pacman->direction;
	_pacman->sourceRect->X = _pacman->sourceRect->Width * _pacman->frame;

}

void Pacman::UpdateMunchie(Enemy*_munchie, int elapsedTime)
{
	//animates munchie
		_munchie->currentFrameTime += elapsedTime;

		if (_munchie->currentFrameTime > _munchie->frameTime)
		{
			_munchie->frame++;

			if (_munchie->frame >= 2)
			{
				_munchie->frame = 0;
			}
			_munchie->currentFrameTime = 0;
			_munchie->sourceRect->X = _munchie->sourceRect->Width * _munchie->frameCount;
		}
}

void Pacman::UpdateGhosts(MovingEnemy* ghost, int elapsedTime)
{
	//directions for animation and movement
	if (ghost->direction == 0)
	{
		ghost->position->X += ghost->speed * elapsedTime;
	}
	else if (ghost->direction == 1)
	{
		ghost->position->X -= ghost->speed * elapsedTime;
	}
	else if (ghost->direction == 2)
	{
		ghost->position->Y += ghost->speed * elapsedTime;
	}
	else if (ghost->direction == 3)
	{
		ghost->position->Y -= ghost->speed * elapsedTime;
	}

	//change direction if the ghost hits a wall
	if (ghost->position->X + ghost->sourceRect->Width >= Graphics::GetViewportWidth())
	{
		ghost->direction = 1;
	}
	else if (ghost->position->X <= 0)
	{
		ghost->direction = 0;
	}

	if (ghost->position->Y + ghost->sourceRect->Height >= Graphics::GetViewportHeight())
	{
		ghost->direction = 3;
	}
	else if (ghost->position->Y <= 0)
	{
		ghost->direction = 2;
	}

	//animates ghost
	ghost->currentFrameTime += elapsedTime;

	if (ghost->currentFrameTime > _cPacmanFrameTime)
	{
		ghost->frame++;

		if (ghost->frame >= 2)
		{
			ghost->frame = 0;
		}

		ghost->currentFrameTime = 0;
	}

	ghost->sourceRect->Y = ghost->sourceRect->Height * ghost->direction;
	ghost->sourceRect->X = ghost->sourceRect->Width * ghost->frame;

	 
}

void Pacman::GhostChaseDirection(MovingEnemy* _ghost, int elapsedTime, int ghostX, int ghostY, int ghostWidth, int ghostHeight, int pacmanX, int pacmanY, int pacmanWidth, int pacmanHeight)
{
	//values assigned to variables for ease of readability
	int ghostLeft = ghostX;
	int pacmanLeft = pacmanX;

	int ghostRight = ghostX + ghostWidth;
	int pacmanRight = pacmanX + pacmanWidth;

	int ghostTop = ghostY;
	int pacmanTop = pacmanY;

	int ghostBottom = ghostY + ghostHeight;
	int pacmanBottom = pacmanY + pacmanHeight;

	//calculates the distance between the ghost and pacman
	int Left = pacmanRight - ghostLeft;
	int Right = ghostRight - pacmanLeft;
	int Top = ghostTop - pacmanBottom;
	int Bottom = pacmanTop - ghostBottom;

   //Changes direction based off of which distance is the shortest
	if (Right < Left && Right < Top && Right < Bottom)
	{
		_ghost->direction = 0;
		
	}
	else if (Left < Right && Left < Top && Left < Bottom)
	{
		_ghost->direction = 1;
		
	}
	else if (Bottom > Right && Bottom > Top && Bottom > Left)
	{
		_ghost->direction = 2;
	
	}
	else if (Top > Right && Top > Bottom && Top > Left)
	{
		_ghost->direction = 3;
		
	}
	
	//move ghost towards pacman
	switch (_ghost->direction)
	{
	case 0:
		_ghost->position->X += _ghost->speed * elapsedTime;
		break;
	case 1:
		_ghost->position->X -= _ghost->speed * elapsedTime;
		break;
	case 2:
		_ghost->position->Y += _ghost->speed * elapsedTime;
		break;
	case 3:
		_ghost->position->Y -= _ghost->speed * elapsedTime;
		break;
	}

	//animate ghost
	_ghost->currentFrameTime += elapsedTime;

	if (_ghost->currentFrameTime > _cPacmanFrameTime)
	{
		_ghost->frame++;

		if (_ghost->frame >= 2)
		{
			_ghost->frame = 0;
		}

		_ghost->currentFrameTime = 0;
	}

	_ghost->sourceRect->Y = _ghost->sourceRect->Height * _ghost->direction;
	_ghost->sourceRect->X = _ghost->sourceRect->Width * _ghost->frame;

}

void Pacman::Draw(int elapsedTime)
{
	// Allows us to easily create a string
	std::stringstream stream;
	stream << " Score: " << score << " Score for Cherry = " << rndScore;

	SpriteBatch::BeginDraw(); // Starts Drawing

	if (!_pacman->isDead)
	{
		SpriteBatch::Draw(_pacman->texture, _pacman->position, _pacman->sourceRect); // Draws Pacman
	}

	//draws munchies
	for (int i = 0; i < MUNCHIECOUNT; i++)
	{

		SpriteBatch::Draw(_munchies[i]->texture, _munchies[i]->position, _munchies[i]->sourceRect);

		if (_munchies[i]->frameCount == 0)
		{
			_munchies[i]->frameCount++;
			_munchies[i]->frame = 1;
		}
		else
		{
			_munchies[i]->frameCount++;

			if (_munchies[i]->frameCount >= 60)
			{
				_munchies[i]->frameCount = 0;
				_munchies[i]->frame = 2;
			}
		}
	}
	
	//draws cherry
	if (drawCherry)
	{
		SpriteBatch::Draw(_cherry->texture, _cherry->position, _cherry->sourceRect);
		if (_cherry->frameCount == 0)
		{
			_cherry->frameCount++;
			_cherry->frame = 1;
		}
		else
		{
			_cherry->frameCount++;

			if (_cherry->frameCount >= 60)
			{
				_cherry->frameCount = 0;
				_cherry->frame = 2;
			}
		}
	}

	//draws ghosts
	for (int i = 0; i < GHOSTCOUNT; i++)
	{
		SpriteBatch::Draw(_ghosts[i]->texture, _ghosts[i]->position, _ghosts[i]->sourceRect);
	}
	//draws start menu
	if (_menu->start)
	{
		std::stringstream startStream;
		startStream << "PRESS SPACE TO START";

		SpriteBatch::Draw(_menu->background, _menu->rectangle, nullptr);
		SpriteBatch::DrawString(startStream.str().c_str(), _menu->stringPosition, Color::Red);
	}

	// Draws String
	SpriteBatch::DrawString(stream.str().c_str(), _stringPosition, Color::Green);
	//draws paused menu
	if (_menu->paused)
	{
		std::stringstream menuStream;
		menuStream << "PAUSED!";

		SpriteBatch::Draw(_menu->background, _menu->rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->stringPosition, Color::Red);

	}
	//if pacman dies, draw game over screen
	if (_pacman->isDead)
	{
		std::stringstream menuStream;
		menuStream << "GAME OVER!";

		SpriteBatch::Draw(_menu->background, _menu->rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->stringPosition, Color::Red);

	}
	//if pacman wins, draw the you win screen
	if (hasWon == true)
	{
		std::stringstream menuStream;
		menuStream << "YOU WIN!";

		SpriteBatch::Draw(_menu->background, _menu->rectangle, nullptr);
		SpriteBatch::DrawString(menuStream.str().c_str(), _menu->stringPosition, Color::Red);
	}


	SpriteBatch::EndDraw(); // Ends Drawing
}